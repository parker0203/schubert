from distutils.core import setup

setup(
        name = 'nester',
        version = '1.1.0',
        py_modules = ['nester'],
        author = 'hfpython',
        author_email = 'email',
        url = 'url',
        description = 'A simple printer of nested lists',
        )
